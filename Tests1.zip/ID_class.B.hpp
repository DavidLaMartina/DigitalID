/*********************************************************************
* Program: Digital ID - ID (object) Class header for Story #1 and #2
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: 	ID class is an object for ID cards the user keeps.
*********************************************************************/

#ifndef	ID_CLASS_B_HPP
#define ID_CLASS_B_HPP
#include <string>
#include <ctime>
#include <vector>


using namespace std;

/* 	An IDMap is a vector container of IDMap_data structures	*/
//-------------------------------
struct IDMap_data
{
	string key;
	string value;
};
//------------------------------


/* 	A DateTime struct  */
//-------------------------------
struct DateTime{
    int year;
    int month;
    int day;
    int hour;
    int minutes;
};


/* 	An ID header struct  */
//-------------------------------
struct IDdata_header{
	DateTime init_date;
	DateTime last_auth;
	time_t init_interval;
	int times_accessed;
};


class ID
{
	protected:
		int ID_reference_number;
		IDdata_header header;
		int num_ID_attributes;
		vector<IDMap_data> ID_attributes;

		string image_path_front = "";           // image path for front of ID
		string image_path_back = "";            // image path for back of ID

	public:
		ID(int);								// Constructor
		int getIDref();							// get ID reference number
		int getNumAttributes();					// Get the number of attributes this ID has
		string requestData (string);			// Get the value by key
		string requestKey (int);				// Get Key string by subscript number
		vector<string> requestDataMap ();		// Get all the keys
		void addAttribute(string, string);		// Add a new key-value pair
		int setValue(string, string);			// Set the value of a key, if the key exist
		bool removeAttribute(string);			// Remove a key-value pair by key
		bool requestAuthentication();			// Request for ID authentication (another class)
		void setInitDate(DateTime&);			// Sets the init_date variable (temporarily a mockup)
		IDdata_header getHeader();				// Get the ID data header struct
		void setHeader(IDdata_header);			// Set the ID data header struct

        int setFrontImgPath(string);            // setters and getters for image paths
        int setBackImgPath(string);
        string getFrontImgPath();
        string getBackImgPath();
		//~ID();								// Deconstructor
};


#endif
