

#ifndef	AUTHENTICATOR_B_HPP
#define AUTHENTICATOR_B_HPP
#include <string>
#include "ID_collection.B.hpp"
//#include "ID_class.B.hpp"

using namespace std;

bool request_external_validation(IDMap_data, int);
int authenticate_ID (ID*);

#endif