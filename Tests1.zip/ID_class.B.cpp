/*********************************************************************
* Program: Digital ID - ID (object) Class for Story #1 and #2
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: 	ID class is an object for ID cards the user keeps.
*********************************************************************/

#include "ID_class.B.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <algorithm>
#include <sys/stat.h>
//#include <ratio>
//#include <chrono>


using namespace std;
//using std::chrono::system_clock;						// Rerefence to example in http://www.cplusplus.com/reference/chrono/system_clock/

#define DEBUG_MODE 0

bool doesPathExist(const string &s);     // Declaration for helper function to determine whether image path exists
string parseFileName(string);     // Declaration for helper function to parse file names (change / to \)

//------------------------------------------------
//
//	ID object constructor
//
//------------------------------------------------
ID::ID(int ID_ref_num)
{
	ID_reference_number = ID_ref_num;
	setInitDate(header.init_date);
	header.last_auth = header.init_date;
	header.times_accessed = 0;
	num_ID_attributes = 1;

	IDMap_data name_data;
	name_data.key = "Name";
	name_data.value = "(no name)";

	ID_attributes.push_back(name_data);

	// Debug
	if(DEBUG_MODE)
	{
		cout << "Added new ID! [Ref No.] : ["<< ID_ref_num <<"] [" << ID_attributes[0].key << "] : [" << ID_attributes[0].value << "] " << endl;
	}
}



//------------------------------------------------
//
//	getIDref
//	Parameters:
//	Return:			- int ID reference number
//
//	Description:
//	Get this ID's system reference number.
//	Should be unique.
//
//------------------------------------------------
int ID::getIDref()
{
	return ID_reference_number;
}


//------------------------------------------------
//
//	getNumAttributes
//	Parameters:
//	Return:			- int number of attributes
//
//	Description:
//	To retrieve the number of attributes this
//	ID object has. Basically length of vector
//	container.
//
//------------------------------------------------
int ID::getNumAttributes ()
{
	return num_ID_attributes;
}

//------------------------------------------------
//
//	requestData function
//	Parameters:		- string key
//	Return:			- string value
//
//	Description:
//	To retrieve a value by key.
//
//------------------------------------------------
string ID::requestData (string search_key)
{
	string v = "(Unidentified - no match key - requested data doesn't exist!)";

	// Search in vector for matching key
	int n = num_ID_attributes;

	for (int i = 0; i < n; i++)
	{
		// Debug
		if(DEBUG_MODE)
		{
			cout << "Searching...(" << i << ") = [" << ID_attributes[i].key << "] : [" << ID_attributes[i].value << "] " << endl;
		}

		if (ID_attributes[i].key == search_key)
		{
			v = ID_attributes[i].value;
		}
	}

	// return corresponding value
	return v;
}


//------------------------------------------------
//
//	requestDataMap function
//	Parameters:
//	Return:			- vector<string> keys
//
//	Description:
//	To retrieve all the keys in that ID.
//
//------------------------------------------------
vector<string> ID::requestDataMap ()
{
	vector<string> k;
	int n = num_ID_attributes;
	// loop through the IDMap data vector
	for (int i = 0; i < n; i++)
	{
		// Debug
		if(DEBUG_MODE)
		{
			cout << "Requesting Data Map...(" << i << ") = [" << ID_attributes[i].key <<  "] " << endl;
		}

		k.push_back(ID_attributes[i].key);

	}
	// write every key string in to k

	return k;
}

//------------------------------------------------
//
//	requestKey function
//	Parameters:		- int k (index)
//	Return:			- string (key string)
//
//	Description:
//	Get a key string by the index
//
//------------------------------------------------
string ID::requestKey (int k)
{
	return ID_attributes[k].key;
}


//------------------------------------------------
//
//	addAttribute function
//	Parameters:		- string key, string value
//	Return:
//
//	Description:
//	Add a key-value pair data to the ID object
//
//------------------------------------------------
void ID::addAttribute(string key, string value)
{
	// Push a new IDMap_data (key value pair) to the vector container
	IDMap_data D;
	D.key = key;
	D.value = value;
	ID_attributes.push_back(D);
	num_ID_attributes++;
}

//------------------------------------------------
//
//	addAttribute function
//	Parameters:		- string key, string value
//	Return:			- return 1 if found and set
//					- return -1 if not found
//
//	Description:
//	Set the value of a key, if the key exist
//
//------------------------------------------------
int ID::setValue(string key, string value)
{
	for (int i = 0; i < num_ID_attributes; i++)
	{
		if (ID_attributes[i].key == key)
		{
			ID_attributes[i].value = value;
			return 1;
		}
	}
	return -1;
}


//------------------------------------------------
//
//	removeAttribute function
//	Parameters:		- string Key
//	Return:			- true if success, else false
//
//	Description:
//	Remove a key-value pair data to the ID object,
//	assuming the key exists in the vector container
//
//------------------------------------------------
bool ID::removeAttribute (string key)
{
	// Loop through the vector
	int n = num_ID_attributes;
	int r = 0;
	for (int i = 0; i < n; i++)
	{
		// if match key
		if (ID_attributes[i].key == key)
		{
			if(DEBUG_MODE)
			{
				cout << "Erasing... ID_attributes("<< i << ") >> [" << ID_attributes[i].key << "] : [" << ID_attributes[i].value << "] " << endl;
			}

			// remove data
			ID_attributes.erase(ID_attributes.begin()+i);
			num_ID_attributes--;

			// return
			return true;
		}
	}

	// return
	return false;
}


//------------------------------------------------
//
//	requestAuthentication function
//	Parameters:
//	Return:			- true if approved, else false
//
//	Description:
//	Use authentication manager function to
//	authenticate this piece of ID
//
//------------------------------------------------
bool ID::requestAuthentication()
{
	return true;
}

//------------------------------------------------
//
//	setInitDate function
//	Parameters:		- DateTime (date of ID initialization)
//	Return:
//
//	Description:
//	A mockup function to write in the init date for
// 	an ID. Supposed to get current date and time.
//
//------------------------------------------------
void ID::setInitDate(DateTime &init_date)
{
	init_date.year = 2018;
	init_date.month = 11;
	init_date.day = 24;
	init_date.hour = 13;
	init_date.minutes = 01;
}

//------------------------------------------------
//
//	getHeader function
//	Parameters:
//	Return:			- return ID data header struct
//
//	Description:
//	Getter function for the header data.
//
//------------------------------------------------
IDdata_header ID::getHeader()					// Get the ID data header struct
{
	return header;
}


//------------------------------------------------
//
//	setHeader function
//	Parameters:		- IDdata_header struct
//	Return:
//
//	Description:
//	Copies the value of the passed in header
//	to this ID's header.
//
//------------------------------------------------
void ID::setHeader(IDdata_header h)				// Set the ID data header struct
{
	header.init_date = h.init_date;
	header.last_auth = h.last_auth;
	header.init_interval = h.init_interval;
	header.times_accessed = h.times_accessed;
}

//------------------------------------------------
//
//	setters for image paths
//	Parameters:		- string (image file path)
//	Return:         - 1 if success, -1 if not
//
//	Description: Sets the image path to a given
//      path
//------------------------------------------------
int ID::setFrontImgPath(string path)
{
    // First replace '/' with '\'
    path = parseFileName(path);

    // Now check whether path exists
    if (doesPathExist(path))
    {
        image_path_front = path;
        return 1;
    }
    else
    {
        return -1;
    }
}
int ID::setBackImgPath(string path)
{
    // First replace '/' with '\'
    path = parseFileName(path);

    // Now check whether path exists
    if (doesPathExist(path))
    {
        image_path_back = path;
        return 1;
    }
    else
    {
        return -1;
    }
}

//------------------------------------------------
//
//	getters for image paths
//	Parameters:		-
//	Return:         - string path
//
//	Description: Gets the image path
//------------------------------------------------
string ID::getFrontImgPath()
{
    return image_path_front;
}
string ID::getBackImgPath()
{
    return image_path_back;
}

//------------------------------------------------
//
//	doesPathExist
//	Parameters:		- string path
//	Return:         - boolean value
//
//	Description: Determines whether or not the
//      user-specified path exists
//
//  Credit to Eric Z Ma at
//  https://www.systutorials.com/topic/how-to-test-a-file-or-directory-exists-in-c/
//------------------------------------------------
bool doesPathExist(const string &s)
{
    struct stat buffer;
    return (stat (s.c_str(), &buffer) == 0);
}

//------------------------------------------------
//
//	parseFileName
//	Parameters:		- string path
//	Return:         - parsed string
//
//	Description: Replaces \ with / in filename
//
//  Credit to Fred Larson at
//  https://stackoverflow.com/questions/4444486/replace-backward-slashes-with-forwards-slashes-or-double-backward-slashes-in-c
//------------------------------------------------
string parseFileName(string path)
{
    replace(path.begin(), path.end(), '\\', '/');
    return path;
}

//------------------------------------------------
//
//	ID object deconstructor
//
//------------------------------------------------
// ID::~ID()
// {
// 	ID_attributes.clear();
// }
