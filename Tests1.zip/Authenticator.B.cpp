#include <iostream>
#include <string>
#include <vector>
#include "Authenticator.B.hpp"

using namespace std;

//------------- Demo ID with correct data ---------------
// "Name", "OSU Instructor ID"
// "ONID", "rookert"
// "Class", "CS361"
// "Gender", "M"
//-------------------------------------------------------


bool request_external_validation(IDMap_data obj[], int attribute_num)
{
	bool valid = true;
	int correct_pairing = 0;
	if (attribute_num != 4)
	{
		valid = false;
	}
	for (int i = 0; i < 4; i++)
	{
		if (obj[i].key == "Name" && obj[i].value == "OSU Instructor ID")
		{
			correct_pairing++;
			break;
		}
	}
	for (int i = 0; i < 4; i++)
	{
		if (obj[i].key == "ONID" && obj[i].value == "rookert")
		{
			correct_pairing++;
			break;
		}
	}
	for (int i = 0; i < 4; i++)
	{
		if (obj[i].key == "Class" && obj[i].value == "CS361")
		{
			correct_pairing++;
			break;
		}
	}
	for (int i = 0; i < 4; i++)
	{
		if (obj[i].key == "Gender" && obj[i].value == "M")
		{
			correct_pairing++;
			break;
		}
	}

	if (correct_pairing != 4)
	{
		valid = false;
	}

	cout << "(DEBUG) External : valid" << endl ;
	return valid;
}


//------------------------------------------------
//
//  Authentication function
//  Parameters:     int ID_ref
//  Return:         - int -1 if ID not found
//                  - int 1 if successul
//                  - int 0 if unsuccessul
//
//  Description:
//  Authenticate the ID with the passed in ref num
//  Pack a json format array (string-string pair)
//  and sends to external 3rd party server 
//  to verify the data.
//  Currently a mockup (no database, using demo ID)
//
//------------------------------------------------

int authenticate_ID (ID* thisID)
{
	if (thisID == NULL)
	{
		cout << "[!]Authenticator.B::authenticate_ID() : could not find reference number in collection!! (bug)" << endl;
		return -1;
	}
	else
	{
		int n = thisID->getNumAttributes();
		IDMap_data obj[n];						// struct type defined in ID_class.B.hpp. Basically string-string pairing
		
		for (int i = 0; i < n; i++)
		{
			obj[i].key = thisID->requestKey(i);
			obj[i].value = thisID->requestData(obj[i].key);
		}

		bool valid = request_external_validation(obj, n);

		if (valid)
		{
			cout << "(DEBUG) authenticate_ID : valid" << endl ;
			return 1;
		}

	}

	return 0;

}