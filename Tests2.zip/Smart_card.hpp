/*********************************************************************
* Program: Digital ID - Smart card header file
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/30/2018
* Description: 	Smart card addition to the Digital ID wallet.
*********************************************************************/

#ifndef SMART_CARD_HPP
#define SMART_CARD_HPP

#include "ID_class.hpp"
#include "ID_collection.hpp"

// ID attribute keys
const string org = "Company_name";
const string fname = "First_name";
const string lname = "Last_name";
const string misc = "other";
const string smart = "Smart_card";

void add_smart_card(string first, string last, string company, string type, ID_collection* wallet);
ID* select_smart_card(ID_collection* wallet);
vector<ID*> search_smart_card(ID_collection* wallet);
void display_smart_cards(vector<ID*> smart_card_list);

#endif