/*********************************************************************
* Program: Digital ID - ID Collection Class header
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/30/2018
* Description: 	ID Collection class keeps a container of IDs,
*				public functions for managing the container
*********************************************************************/

#include "ID_collection.hpp"
#include <iostream>
#include <string>
#include <vector>

using namespace std;


//------------------------------------------------
//
//	ID Storage object constructor
//
//------------------------------------------------
ID_collection::ID_collection()
{
	num_ID = 0;
	nextRefNum = 1;
}


/*

Main Operation Functions

*/
int ID_collection::getNumID()
{
	return num_ID;
}


//------------------------------------------------
//
//	Get ID function
//	Parameters:		int ID_ref
//	Return:			- struct ID_object *
//					- NULL
//
//	Description:
//	Get an ID pointer by the reference number of
//	the user ID.
//	Use the Find ID function to get the index in
//	the ID list first,
//	then retrieve the pointer.
//	If ID does not exist, return NULL.
//
//------------------------------------------------
ID* ID_collection::getID(int ID_ref)
{
	ID * thisID = NULL;
	int index = -1;

	// Find ID index by ID_ref pass to index
	index = findID(ID_ref);
	if (index != -1)
	{
		// set thisID to point to the ID object in the collection[index]
		thisID = myCollection[index];
	}

	return thisID;
}

//------------------------------------------------
//
//	Set ID function
//	Parameters: 	int ID_ref, ID* thisUpdateID
//	Return:			- int 1 if successful
//					- int -1 if id ref is not found
//					- int -2 if this ID is not valid
//
//	Description:
//	Assuming the data has been validated,
//  and that the ID does exist in storage,
//	this sets the data to an existing ID.
//	Use the findID function to get the
//	index subscript.
//
//------------------------------------------------
int ID_collection::setID(int ID_ref, ID* thisUpdateID)
{

	ID * thisSlot = NULL;
	int i;
	bool validID = false;

	// Authenticate thisUpdateID, pass return to validID
	validID = authenticate(thisUpdateID);
	// if validID true
	if (validID)
	{
		// Find the ID and get the index
		i = findID(ID_ref);

		// if FindID cannot find any matching ID, then return -1
		if (i == -1)
		{
			return -1;
		}

		// Delete the current ID object from the collection (call deconstructor)
		delete myCollection[i];

		// Add the new one in
		myCollection[i] = thisUpdateID;

		// return 1;
		return 1;
	}

	// else return -2;
	return -2;
}

//------------------------------------------------
//
//	Remove ID function
//	Parameters:		int ID_ref
//	Return: 		- int 1 if succesully remove
//					- int -1 if it does not exist
//
//	Description:
//	Removes an ID object from the collection by
//	ref number of the ID. Vector has 1 data shorter.
//	Return 1 if successfully removed, -1 if
//	the ID doesn't exist
//
//------------------------------------------------
int ID_collection::removeID(int ID_ref)
{
	int result = -1;
	int index = -1;

	// get the index of the ID in the container
	index = findID(ID_ref);

	if (index >= 0)
	{
		// remove the current object
		myCollection.erase(myCollection.begin() + index);
		num_ID--;
		result = 1;
	}
	return result;

}


//------------------------------------------------
//
//	Create ID function
//	Parameters:
//	Return: 		- ID pointer
//
//	Description:
//	Creates an empty data ID
//	writes the reference number in
//	and returns the ID pointer
//
//------------------------------------------------
ID* ID_collection::addID()
{
	// Create a new ID with the next available reference number passed in
	ID * ptr = new ID(getNextRef());

	// push new ID to myCollection vector
	myCollection.push_back(ptr);
	num_ID++;

	return ptr;
}



//------------------------------------------------
//
//	Get ID list function
//	Parameters:
//	Return: 		- myCollection (ID* vector)
//
//	Description:
//	Returns the collection
//
//------------------------------------------------
vector<ID*> ID_collection::getIDList()
{
	return myCollection;
}



/*

Helper Functions

*/


//------------------------------------------------
//
//	Find ID function
//	Parameters:		int ID_ref
//	Return: 		- int index of the vector
//					- int -1 if it does not exist
//
//	Description:
//	Searches through the list to find the matching
//	ref number of the ID.
//	Return the index in the vector.
//
//------------------------------------------------
int ID_collection::findID(int ID_ref)
{
	int index = -1;

	// Loop through myCollection
	for (int i = 0; i < num_ID; i++)
	{
		// if ID_ref matches
		if (myCollection[i]->getIDref() == ID_ref)
		{
			// index = i
			index = i;
		}
	}
	return index;
}

//------------------------------------------------
//
//	Get Next ref number
//	Parameters:
//	Return: 		- int newRefNum
//
//	Description:
//	Generate an available (unique) ref number.
//	Returns the number.
//	This is a mockup function.
//
//------------------------------------------------
int ID_collection::getNextRef()
{
	int num = nextRefNum;
	nextRefNum++;
	return num;
}


//------------------------------------------------
//
//	ID Authentication
//	Parameters:		- pointer to ID
//	Return: 		- bool
//
//	Description:
//	This is a mockup authentication.
//
//------------------------------------------------
bool ID_collection::authenticate(ID* thisID)
{
	return true;
}



//------------------------------------------------
//
//	ID Storage object deconstructor
//
//------------------------------------------------
ID_collection::~ID_collection()
{
	for (int i = 0; i < num_ID; i++)
	{
		delete myCollection[i];
	}
	myCollection.clear();
}