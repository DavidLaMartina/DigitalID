/*********************************************************************
* Program: Digital ID - ID (object) Class header
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/30/2018
* Description: 	ID class is an object for ID cards the user keeps.
*********************************************************************/

#ifndef	ID_CLASS_HPP
#define ID_CLASS_HPP
#include <string>
#include <ctime>
#include <vector>

using namespace std;

/* 	An IDMap is a vector container of IDMap_data structures	*/
//-------------------------------
struct IDMap_data
{
	string key;
	string value;
};
//------------------------------


/* 	A DateTime struct  */
//-------------------------------
struct DateTime
{
	int year;
	int month;
	int day;
	int hour;
	int minutes;
};
//-------------------------------

class ID
{
protected:
	int ID_reference_number;
	DateTime init_date;
	DateTime last_auth;
	time_t init_interval;
	int times_accessed;
	int num_ID_attributes;
	vector<IDMap_data> ID_attributes;

public:
	ID(int);								// Constructor
	int getIDref();							// get ID reference number
	int getNumAttributes();					// Get the number of attributes this ID has
	string requestData(string);			// Get the value by key
	string requestKey(int);				// Get Key string by subscript number
	vector<string> requestDataMap();		// Get all the keys
	void addAttribute(string, string);		// Add a new key-value pair
	int setValue(string, string);			// Set the value of a key, if the key exist
	bool editAttribute(string, string);	// Edit an existing value
	bool removeAttribute(string);			// Remove a key-value pair by key
	bool requestAuthentication();			// Request for ID authentication (another class)
	void setInitDate(DateTime&);			// Sets the init_date variable (temporarily a mockup)
	//~ID();									// Deconstructor
};

#endif