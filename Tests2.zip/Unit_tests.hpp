/**************************************************************************************************
* Program: Digital ID - Unit Tests - Story 7: Inspection ID (ID Viewer)
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/30/18
* Description: Unit test declarations and definitions for story 7
**************************************************************************************************/

#ifndef UNIT_TESTS_HPP
#define UNIT_TESTS_HPP

#include "Smart_card.hpp"
#include <fstream>
#include <iostream>
#include <sstream>

/*
* validate_int is a helper function to validate user input for the menu selections
*
* @params: range for desired validation, min for minimum allowed value and max for maximum allowed value
*
* returns validated int
*/
int validate_int(int min, int max)
{
	bool errorFlag = false; //bool to flag when input becomes valid
	string input; //string to hold line of input
	int validInt; //integer for function to return

	do
	{
		//read the line of input entered by user into input string
		getline(std::cin, input);

		//initialize stringstream variable with input string
		std::stringstream inputStream(input);

		//check if stringstream object will convert with nothing left over
		if (inputStream >> validInt && !(inputStream >> input))
		{
			//check if input is within bounds
			if (validInt < min || validInt > max)
			{
				std::cout << "Please enter an integer between " << min << " and " << max << std::endl;
			}
			else //input was successfully converted and within bounds
			{
				//flag that input is ready to be returned
				errorFlag = true;
			}
		}
		else //user did not enter an integer value
		{
			std::cout << "Please enter an integer" << std::endl;
		}
	} while (errorFlag == false);

	return validInt;
}

/*
* validate_string is a helper function to validate user input for strings
*
* @params: none
*
* returns a validated/non-empty string
*/
string validate_string()
{
	string input = ""; //holds the string being validated

	getline(cin, input);

	//ask user to enter valid string (non-empty)
	while (input.length() == 0)
	{
		cout << "Please enter a non-blank input." << endl;
		getline(cin, input);
	}

	return input;
}

/*
* sets up a collection for testing
*
* @params: none
*
* returns a pointer to created collection object
*/
ID_collection* setupCollection()
{
	ID* currID; //pointer to currently held ID

	//create object
	ID_collection* wallet = new ID_collection();

	//ID data strings
	string idNames[5] = { "Driver License", "Gym", "Passport", "Laptop", "Work FOB" };
	string idMisc[5] = { "C", "Runner", "USA", "topSecret", "frontDoor" };

	//add some IDs
	for (int i = 0; i < 5; i++)
	{
		//populate some data
		currID = wallet->addID();
		currID->editAttribute("Name", idNames[i]);
		currID->addAttribute("fname", "John");
		currID->addAttribute("lname", "Doe");
		currID->addAttribute("other", idMisc[i]);
	}

	return wallet;
}


/*
* inspectIDs function runs interactive menu to demonstrate the data that
* is available to user when viewing an ID
*
* @param: vector holding IDs to be tested
*/
void inspectIDs(ID_collection* wallet)
{
	//placeholder "images" for IDs
	string frontID =
		"\n----------------------------------------------------------\n"
		"|                                                        |\n"
		"|                   [FRONT IMAGE OF ID]                  |\n"
		"|                                                        |\n"
		"----------------------------------------------------------\n";

	string backID =
		"\n----------------------------------------------------------\n"
		"|                                                        |\n"
		"|                   [BACK IMAGE OF ID]                   |\n"
		"|                                                        |\n"
		"----------------------------------------------------------\n";

	vector<ID*> myWallet;
	ID* currID;
	bool runWallet = true;					//flag for wallet menu iteration
	bool runID = true;						//flag for ID menu iteration
	int walletChoice;						//ID option selection from wallet
	int idChoice;							//attribute option selection from ID
	int editChoice;							//attribute field selection from ID
	int numAttributes;						//number of attributes on ID
	string newValue;						//new value placeholder for editing IDs
	string newKey;							//new key placeholder for editing IDs
	vector<string> idKeys;					//holds keys of attributes for selected ID

	//view IDs in wallet until user elects to exit testing menu
	while (runWallet)
	{
		//get the current collection of IDs
		myWallet = wallet->getIDList();

		std::cout
			<< "===========================================================" << std::endl
			<< "=====                                                 =====" << std::endl
			<< "=====      [Digital ID Wallet Inspection Screen]      =====" << std::endl
			<< "=====                                                 =====" << std::endl
			<< "===========================================================" << std::endl << std::endl;

		std::cout << "Available IDs to View:" << std::endl;
		//display available IDs
		for (int i = 0; i < wallet->getNumID(); i++)
		{
			std::cout << "[" << i + 1 << "] " << myWallet[i]->requestData("Name") << std::endl;
		}

		std::cout << "[" << wallet->getNumID() + 1 << "] Exit Testing Application\n" << std::endl;

		std::cout << "Please select an ID to inspect [enter ID number]:";

		//get user input for ID to inspect
		walletChoice = validate_int(1, wallet->getNumID() + 1);

		if (walletChoice == wallet->getNumID() + 1)
		{
			//exit menu
			return;
		}
		else
		{
			//grab selected ID from wallet
			currID = myWallet[walletChoice - 1];

			//reset menu flag
			idChoice = 0;

			//placeholder for ID images
			string screenID = frontID;

			while (runID) //until user removes or exits selected ID
			{
				//inspect selected ID
				std::cout << "\n" << currID->requestData("Name") << ":";
				std::cout << screenID << std::endl;

				std::cout
					<< "[1] Flip ID" << std::endl
					<< "[2] Edit ID" << std::endl
					<< "[3] Remove ID" << std::endl
					<< "[4] Return to Wallet" << std::endl
					<< "\nPlease select an option [enter menu number]:";

				//get user input for ID option
				idChoice = validate_int(1, 4);

				switch (idChoice)
				{
				case 1: //flip ID
					if (screenID == frontID)
						screenID = backID;
					else
						screenID = frontID;
					break;
				case 2: //edit ID

					//get attribute count
					numAttributes = currID->getNumAttributes();
					//reset choice
					editChoice = 0;

					while (editChoice != (numAttributes + 2)) //until user wants to stop editing
					{
						//get attribute count
						numAttributes = currID->getNumAttributes();
						// Get all the keys
						idKeys = currID->requestDataMap();

						std::cout << "\nAttributes Available to Edit:" << std::endl;

						//display attributes available to edit
						for (int i = 0; i < numAttributes; i++)
						{
							std::cout << "[" << i + 1 << "] " << idKeys[i] << ": " << currID->requestData(idKeys[i]) << std::endl;
						}

						std::cout << "[" << numAttributes + 1 << "] Add new" << std::endl
							<< "[" << numAttributes + 2 << "] Cancel Edit" << std::endl
							<< "\nPlease select an attribute to edit [enter menu number]:";

						//get user selection
						editChoice = validate_int(1, numAttributes + 2);

						if (editChoice != (numAttributes + 2)) //if user doesn't choose to cancel
						{
							if (editChoice == (numAttributes + 1)) //add new attribute
							{
								std::cout << "\nEnter new key: ";
								newKey = validate_string();

								std::cout << "\nEnter new value for key: ";
								newValue = validate_string();

								//add new attribute to ID
								currID->addAttribute(newKey, newValue);
							}
							else //edit existing attribute
							{
								std::cout << "\nEnter new value for key [" << idKeys[editChoice - 1] << "]: ";

								//get new value
								newValue = validate_string();

								//enact edit to ID
								currID->editAttribute(idKeys[editChoice - 1], newValue);
							}
						}
						//else cancel editing
					}

					break;
				case 3: //remove ID

					std::cout << "\nAre you sure you want to remove " << currID->requestData("Name") << " from your Digital ID wallet?" << std::endl
						<< "[1] Yes" << std::endl << "[2] No" << std::endl;

					editChoice = validate_int(1, 2);

					if (editChoice == 1) //remove ID from wallet
					{
						wallet->removeID(currID->getIDref());

						//update flag to exit menu
						runID = false;
					}
					//else do nothing

					break;
				case 4: //return to wallet

					//update flag
					runID = false;

					break;
				}
			}

			//reset flag
			runID = true;
		}


	}
}

//------------------------------------------------------------------------------

/**
 * test_smart_card function uses sample inputs from a file and
 * creates a test wallet with the first three elements being
 * random IDs. The fourth and fifth elements are smart cards
 * which will be added by the add_smart_card function. We then
 * test if the addition of the smart cards were succesful.
 */
void test_smart_card()
{
    cout << "\n\n\n\n\n\n"
         << "*********************************************\n"
         << "*        Testing Smart Card Addition        *\n"
         << "*********************************************\n" << endl;

    // Get inputs from file
    ifstream ifs("add.txt");
    if(!ifs.is_open())
    {
        cout << "File Opening Error!" << endl;
    }
    ID_collection* sample = new ID_collection();

    // First 3 elements of vector are not smart cards
    int count;
    string first, last;
    ifs >> count >> first >> last;

    for(int i = 0; i < count; i++)
    {
        string ID_type;
        ifs >> ID_type;

        ID* testID = sample->addID();
        testID->editAttribute("Name", ID_type);
        testID->addAttribute(fname, first);
        testID->addAttribute(lname, last);
        testID->addAttribute(misc, "none");
    }

    // Add two smart cards then check if succesful
    // Indexes used for these cards will be 4 and 5
    add_smart_card(first, last, "IBM", "Entrance Key", sample);
    add_smart_card(first, last, "Apple", "Server Room Entry", sample);

    if((sample->getNumID()) < 5)
    {
        cout << "Smart card addition: FAILED!\n\n" << endl;
    }
    else
    {
        vector<ID*> cards = sample->getIDList();
        display_smart_cards(cards);
        cout << "Smart card addition: PASSED!\n\n" << endl;

    }

    // Test smart card selection
    cout << "\n\n\n\n\n\n"
         << "*********************************************\n"
         << "*        Testing Smart Card Selection       *\n"
         << "*********************************************\n" << endl;
    ID* user_select = select_smart_card(sample);

    // Null ptr means that there are no smart cards available
    if(!user_select)
    {
        cout << "Smart card selection: FAILED!\n\n";
    }
    else if(user_select)
    {
        cout << "Smart card selection: Passed!\n\n";
    }

    sample->~ID_collection();
}

#endif