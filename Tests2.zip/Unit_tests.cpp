/**************************************************************************************************
* Program: Digital ID - Unit Tests - Story 7: Inspection ID (ID Viewer)
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/30/18
* Description: Unit test for story 7
**************************************************************************************************/

#include "Unit_tests.hpp"

int main(int argc, char const *argv[])
{
    // Load sample IDs
	ID_collection* wallet;
	wallet = setupCollection();

	//test inspect ID function
	inspectIDs(wallet);

    // Testing add and update functions
    test_smart_card();

	return 0;
}