/*********************************************************************
* Program: Digital ID - Smart card implementation file
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/30/2018
* Description: 	Smart card addition and selection to Digital ID wallet.
*********************************************************************/

#include "Smart_card.hpp"
#include <iostream>

/**
 * add_smart_card function initializes a new ID with
 * an attribute value called smart_card. This is done
 * to differentiate it from regular IDs in the wallet.
 *
 * @param: first name , last name, company name, and ID reference number
 */
void add_smart_card(string first, string last, string company, string type, ID_collection* wallet)
{
    // Add new smart card to collection
    ID* add_card = wallet->addID();

    // Add relevant attributes
    add_card->editAttribute("Name", smart);
    add_card->addAttribute(fname, first);
    add_card->addAttribute(lname, last);
    add_card->addAttribute(org, company);
    add_card->addAttribute(misc, type);
}

/**
 * select_smart_card function searches the wallet for all
 * the available smart cards that the user has stored. It then
 * displays the available smart cards to the user and allows them
 * to make a choice. This function returns the pointer to the
 * smart card ID.
 *
 * @param: Id collection wallet
 */
ID* select_smart_card(ID_collection* wallet)
{
    vector<ID*> smart_card_list = search_smart_card(wallet);

    // Check if there are any smart cards available
    if(smart_card_list.empty())
    {
        return nullptr;
    }

    // Display smart cards
    display_smart_cards(smart_card_list);

    // Get user's choice
    int choice;
    cout <<"Select Smart Card Number: ";
    cin >> choice;

    if((choice < 1) || (choice > smart_card_list.size()))
    {
        return nullptr;
    }

    return smart_card_list[choice-1];
}

/**
 * search_smart_card function searches the ID collection
 * for all the available smart cards that a user can select from.
 * This returns a vector that can be used to narrow down which card
 * the user wants to select.
 *
 * @param: Id collection wallet
 */
vector<ID*> search_smart_card(ID_collection* wallet)
{
    vector<ID*> ID_list = wallet->getIDList();

    // Find all smart cards for user to select from
    vector<ID*> smart_cards;
    for(vector<ID*>::size_type i = 0; i != ID_list.size(); i++)
    {
        if(ID_list[i]->requestData("Name") == smart)
        {
            smart_cards.push_back(ID_list[i]);
        }
    }

    return smart_cards;
}

/**
 * display_smart_cards displays the type of card, first and last names,
 * company name, and misc info about smart cards.
 *
 * @param: ID* vector of cards
 */
void display_smart_cards(vector<ID*> smart_card_list)
{
    // Display smart cards
    cout << "List of available cards" << endl;
    for(vector<ID*>::size_type i = 0; i != smart_card_list.size(); i++)
    {
        cout << "Card #" << i+1 <<" \n"
             << "Name: " << smart_card_list[i]->requestData("Name") << '\n'
             << "First Name: " << smart_card_list[i]->requestData(fname) << '\n'
             << "Last Name: " << smart_card_list[i]->requestData(lname) << '\n'
             << "Company: " << smart_card_list[i]->requestData(org) << '\n'
             << "Misc: " << smart_card_list[i]->requestData(misc) << "\n\n";
    }
}