/**************************************************************************************************
* Program: Digital ID - ID lock implementation file for stories 14 & 15
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/18
* Description: ID lock searches for the key related to ID status and changes its status value.
**************************************************************************************************/

#include "ID_lock.hpp"
#include <iostream>

/*
* Lock function takes the specific ID user has selected
* and sets its ID valid key to locked. This should prevent
* the authenticator from allowing the use of this specific ID.
*
* @param: id that user has selected
*/
void Lock(ID &id)
{
	bool lockSuccess = id.editAttribute(valid, lock);
}

/*
* Unlock function takes the specific ID that a user has
* selected and changes its ID valid key attribute to unlocked.
* This should allow the authenticator to use this ID.
*
* @param: id that user has selected
*/

void Unlock(ID &id)
{
	bool unlockSuccess = id.editAttribute(valid, unlock);
}