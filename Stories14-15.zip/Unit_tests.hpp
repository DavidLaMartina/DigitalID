/**************************************************************************************************
* Program: Digital ID - ID lock status unit tests for stories 14 & 15
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/18
* Description: Unit test declarations and definitions for stories 14 & 15.
**************************************************************************************************/

#ifndef UNIT_TESTS_HPP
#define UNIT_TESTS_HPP

#include "ID_lock.hpp"
#include <fstream>
#include <iostream>

/*
* Load id function creates sample IDs into a vector to run
* tests on.
*
* @param: ifs file stream to read in sample data
*/
void loadID(std::ifstream &ifs, vector<ID> &wallet)
{
	// Number of IDs in sample file
	int count;
	string fname, lname, idType;

	ifs >> count >> fname >> lname;
	for (int i = 0; i < count; i++)
	{
		ID testID(i);
		ifs >> idType;

		// Set attributes
		testID.addAttribute("fname", fname);
		testID.addAttribute("lname", lname);
		testID.addAttribute("ID_type", idType);
		testID.addAttribute(valid, unlock);

		// Add to wallet
		wallet.push_back(testID);
	}
}

/*
* Test id function runs basic tests to determine if
* locking functionality is working properly
*
* @param: vector holding IDs to be tested
*/
void testIDLocks(vector<ID> &wallet)
{
	int numSuccess = 0, numFailures = 0; //for diagnostic report
	int testLocks = wallet.size();	//control for loop termination
	int testUnlocks = testLocks;

	//perform lock operations on each ID
	std::cout << "Performing Lock Testing:" << std::endl
		<< "----------------------------" << std::endl;
	for (int i = 0; i < testLocks; i++)
	{
		std::cout << "Testing ID: " << wallet[i].getIDref() << std::endl;
		std::cout << "Current Lock Status: " << wallet[i].requestData(valid) << std::endl;

		//attempt to lock ID
		std::cout << "Attempting to lock " << wallet[i].getIDref() << "..." << std::endl;
		Lock(wallet[i]);

		if (wallet[i].requestData(valid) == lock)
		{
			std::cout << "SUCCESS: " << wallet[i].getIDref() << " is now locked" << std::endl;
			numSuccess++;
		}
		else
		{
			std::cout << "ERROR: " << valid << "Status is: " << wallet[i].requestData(valid) << std::endl;
			numFailures++;
		}
	}

	//perform unlock operations on each ID
	std::cout << "\nPerforming Unlock Testing:" << std::endl
		<< "----------------------------" << std::endl;

	for (int i = 0; i < testUnlocks; i++)
	{
		std::cout << "Testing ID: " << wallet[i].getIDref() << std::endl;
		std::cout << "Current Lock Status: " << wallet[i].requestData(valid) << std::endl;

		//attempt to unlock ID
		std::cout << "Attempting to unlock " << wallet[i].getIDref() << "..." << std::endl;
		Unlock(wallet[i]);

		if (wallet[i].requestData(valid) == unlock)
		{
			std::cout << "SUCCESS: " << wallet[i].getIDref() << " is now unlocked" << std::endl;
			numSuccess++;
		}
		else
		{
			std::cout << "ERROR: " << valid << "Status is: " << wallet[i].requestData(valid) << std::endl;
			numFailures++;
		}
	}

	std::cout << "\n****************************" << std::endl
		<< "TEST RESULTS:" << std::endl
		<< "Total Tests Run: " << testLocks + testUnlocks << std::endl
		<< "Number of SUCCESSES: " << numSuccess << std::endl
		<< "Number of FAILURES: " << numFailures << std::endl
		<< "****************************" << std::endl;
}

#endif