/**************************************************************************************************
* Program: Digital ID - ID lock status unit tests for stories 14 & 15
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/18
* Description: Load sample IDs and tests the successful unlocking/locking process for each ID.
**************************************************************************************************/

#include "Unit_tests.hpp"

int main(int argc, char const *argv[])
{
	std::ifstream ifs("sample.txt");
    if(!ifs.is_open())
    {
        std::cout << "File Opening Error!" << std::endl;
        return 1;
    }

    // Load sample IDs
    vector<ID> wallet;
    loadID(ifs, wallet);

	//test lock/unlock functions
	testIDLocks(wallet);

    ifs.close();
	return 0;
}