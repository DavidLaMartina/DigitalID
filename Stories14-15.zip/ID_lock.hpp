/**************************************************************************************************
* Program: Digital ID - ID lock header file for stories 14 & 15
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/18
* Description: ID lock searches for the key related to ID status and changes its status value.
**************************************************************************************************/

#ifndef ID_LOCK_HPP
#define ID_LOCK_HPP

#include "ID_class.hpp"

// Key and value pair for ID status
const string valid = "ID_Valid";
const string lock = "ID_Locked";
const string unlock = "ID_Unlocked";

void Lock(ID &id);
void Unlock(ID &id);

#endif