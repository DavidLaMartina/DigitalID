/**************************************************************************************************
* Program: Digital ID - ID (object) Class header for story 14 & 15
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/18
* Description: ID class is an object for user's ID cards
**************************************************************************************************/

#ifndef ID_CLASS_HPP
#define ID_CLASS_HPP

#include <string>
using std::string;

#include <vector>
using std::vector;

/* An IDMap is a vector container of IDMap_data structures */
struct IDMap_data {
	string key;
	string value;

	IDMap_data(string _key, string _value) {
		key = _key;
		value = _value;
	}
};

struct DateTime {
	int year;
	int month;
	int day;
	int hour;
	int minutes;
};

class ID {
public:
	const int DEFAULT_AUTH_INTERVAL = 7;// Default authentication interval

protected:
	string ID_reference_number;         // Globally unique identifier
	DateTime init_date;                 // Initialization date
	DateTime last_auth;                 // last authentication date
	int auth_interval;                  // re-authentication interval in #days
	int num_ID_attributes;              // total number of attributes in the ID
	vector<IDMap_data> ID_attributes;   // container of actual attributes for the ID

public:
	ID(int);                            // Generic constructor
	ID(int, int);                       // Constructor that takes authentication interval parameter

	string getIDref();                  // Retrieve unique identifier
	DateTime getInitDate();             // Retrieve initialization date
	DateTime getLastAuth();             // Retrieve last authentication date
	int getAuthInterval();              // Retrieve authentication interval
	int getNumAttributes();             // Retrieve number of attributes
	vector<IDMap_data> getAllAttributes();  // Retrieve entire data map (for display, output, etc.)

	string requestData(string);         // Get value by key
	vector<string> requestDataMap();    // Get all available keys (for further query)
	void addAttribute(string, string);  // Add a new key-value pair
	bool editAttribute(string, string);	// Edit an existing value
	bool removeAttribute(string);       // Remove key-value pair by key
	bool requestAuthentication();       // Request for ID authentication

	string generateUID(int);            // Generates unique identifier string
	DateTime getCurrentDateTime();      // Offers up current date in DateTime format

	~ID();                              // Destructor
};

#endif // ID_CLASS_HPP_HPP_INCLUDED