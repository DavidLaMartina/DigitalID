/**************************************************************************************************
* Program: Digital ID -
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description:
**************************************************************************************************/

#ifndef ID_COLLECTION_HPP
#define ID_COLLECTION_HPP

#include "ID_class.hpp"

#include <string>
using std::string;
// using std::to_string;

#include <vector>
using std::vector;

class ID_collection
{
    protected:
        int num_ID;                         // number of IDs in the container
        int nextRefNum;                     // Next available reference number
        vector<ID*> myCollection;           // actual container of IDs

    public:
        ID_collection();                    // constructor of collection class object

        int getIDCount();                   // Retrieves current ID count
        ID* getID(string);                  // Get ID pointer by unique reference string
        int setID(ID*);                     // Update existing ID w/ pointer to updated copy
        int removeID(string);               // Remove ID from collection
        ID* addID(string);                  // Add new ID to collection (empty)
        vector<ID*> getIDList();            // Returns entire collection
        int getNextRefNum();                // Returns next available reference number
        bool authenticate(ID*);             // Returns true if ID data is valid
        int findID(string);                 // Get vector index of ID by string reference number

        ~ID_collection();                   // Deconstructor
};

#endif // ID_COLLECTION_HPP_INCLUDED
