/*********************************************************************  
* Program: Digital ID - Unit tests for Story #1
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: 	Unit tests to ensure ID and ID collection class functions are working properly
*********************************************************************/

#include <iostream>
#include <string>
#include <vector>
#include "ID_collection.B.hpp"

using namespace std;

// Print All attributes for this ID
void printAttributes(ID* thisID)
{
	vector<string> keys = thisID->requestDataMap();
	cout << "\n\t\tThis ID has [" <<  thisID->getNumAttributes() <<"] attributes: " << endl;
	for (int j = 0; j < thisID->getNumAttributes(); j++)
	{
		cout << "\t\t["<< j << "] > \"" << keys[j] << "\" : \"" << thisID->requestData(keys[j]) << "\"" << endl ;
	}	
	cout << endl;
}

// Print All the stats and data
void printState(vector<ID*> V, int num_ID)
{

	cout << "Container has [" << num_ID << "] IDs ---------- expected [" << V.size() << "] \n" << endl;
	for (int i = 0; i < num_ID; i++)
	{
		cout << "+ [" << i << "]\tRef-no.\t" << V[i]->getIDref() << " : " << endl;
		printAttributes(V[i]);
	}
}

void verify(string k1,string v1, ID* thisID, int i)
{
	string k2 = thisID->requestKey(i);
	string v2 = thisID->requestData(k2);


	cout << "\"" << k2 << "\" : \"" << v2 << "\" ----- expected [\""<< k1 << "\" : \""<< v1 <<"\"] ";
	
	if (k2 == k1 && v2 == v1)
	{
		cout << " ------ PASSED" << endl;
	}
	else
	{
		cout << "------ FAILED " << endl;
	}	
}

void check_attribute_num(ID* thisID, int e)
{
	cout << "\tNumber of attributes is \""<< thisID->getNumAttributes() << "\", expected "<< e <<" ";
	if (thisID->getNumAttributes() == e)
	{
		cout << "---------- PASSED" << endl;
	}
	else
	{
		cout << "---------- FAILED" << endl;
	}

}


int main()
{
	cout << "\n--------------- <ID CLASS> Unit Test Begins -----------------\n\n" << endl;

	//---------------------------------------------------------------
	cout << "TESTING // ID() constructor ... " << endl ;
	//-----------------------------------------------------------------
	ID* thisID = NULL;
	
	thisID = new ID(1);
	cout << "\tTesting if ID pointer is not NULL: ";
	if (thisID == NULL)
	{	cout << "\tFALSE -------- FAILED " << endl; }
	else
	{	cout << "\tTRUE -------- PASSED " << endl; }	


	//---------------------------------------------------------------
	cout << "TESTING // addAttributes() // requestData() // requestKey() ... " << endl;
	//-----------------------------------------------------------------
	
	cout << "\tTesting if adding and requesting attribute is successful... " << endl;

	string k1 = "key 1";
	string v1 = "val 111";
	thisID->addAttribute(k1, v1);
	verify(k1,v1,thisID, 1);

	string k2 = "key 2";
	string v2 = "val 222";
	thisID->addAttribute(k2, v2);
	verify(k2,v2,thisID, 2);

	string k3 = "key 3";
	string v3 = "val 333";
	thisID->addAttribute(k3, v3);
	verify(k3,v3,thisID, 3);

	string k4 = "key 4";
	string v4 = "val 444";
	thisID->addAttribute(k4, v4);
	verify(k4,v4,thisID, 4);


	//---------------------------------------------------------------
	cout << "TESTING // getIDref() ... " << endl;
	//-----------------------------------------------------------------	
	cout << "\tTesting if getIDref returns the correct ID reference number: " << endl;

	cout << "\tRef number of first ID is [" << thisID->getIDref() <<"], expected [1]";
	if (thisID->getIDref() == 1)
	{		cout << "---------- PASSED" << endl;	}
	else
	{		cout << "---------- FAILED" << endl;	}

		// Add a new ID to the collection--------
		ID* thatID = new ID(2);
		string k5 = "key 5";
		string v5 = "val 555";
		thatID->addAttribute(k5, v5);
		string k6 = "key 6";
		string v6 = "val 666";
		thatID->addAttribute(k6, v6);
		//---------------------------------------

	cout << "\tRef number of second ID is [" << thatID->getIDref() <<"], expected [2]";
	if (thatID->getIDref() == 2)
	{		cout << "---------- PASSED" << endl;	}
	else
	{		cout << "---------- FAILED" << endl;	}


	//----------------------------------------------------------------
	cout << "TESTING // requestDataMap() ... " << endl;	
	//-----------------------------------------------------------------
	
	cout << "\tTesting if request dataMap returns a correct set of attribute key strings: " << endl;	

	vector<string> thisID_DataMap = thisID->requestDataMap();
	check_attribute_num(thisID, 5);
	for (int i = 0; i < thisID->getNumAttributes(); i++)
	{
		cout << "\tFor attribute ["<< i << "], requestKey returns [" << thisID->requestKey(i) <<"], expected [" << thisID->requestKey(i) <<"] ";
		if (thisID->requestKey(i) == thisID_DataMap[i])
		{		cout << "---------- PASSED" << endl;		}
		else
		{		cout << "---------- FAILED" << endl;		}
	}
	

	//-----------------------------------------------------------------
	cout << "TESTING // setValue() ... " << endl;	
	//-----------------------------------------------------------------
	cout << "\tTesting if setting a value by the given key string work correctly:" << endl;
	cout << "\tthisID's \"Name\" is set to \"thisID\" " ;
	if(thisID->setValue("Name", "thisID") && thisID->requestData("Name") == "thisID")
	{		cout << "---------- PASSED" << endl;	}
	else
	{		cout << "---------- FAILED" << endl;	}
	cout << "\tthisID's \"Name\" is set to \"thatID\" " ;
	if (thatID->setValue("Name", "thatID") && thatID->requestData("Name") == "thatID")
	{		cout << "---------- PASSED" << endl;	}
	else
	{		cout << "---------- FAILED" << endl;	}
	cout << "\tAttempt to set thisID's \"Foo\" to \"bar\", expect no change";
	if (thatID->setValue("foo", "bar") == -1 && thisID->getNumAttributes() == 5)
	{		cout << "---------- PASSED" << endl;	}
	else
	{		cout << "---------- FAILED" << endl;	}	 



	//-----------------------------------------------------------------
	cout << "TESTING // removeAttribute() ... " << endl;
	//-----------------------------------------------------------------		
	cout << "\tTesting if attribute is removed from the ID correctly: " << endl;

	printAttributes(thisID);

	cout << "\tRemoving 2 attributes, key 1 and key 3..." << endl;
	thisID->removeAttribute(k3);
	thisID->removeAttribute(k1);
	check_attribute_num(thisID, 3);

	cout << "\tThe remaining data are \"" << thisID->requestKey(1) << "\" and \"" << thisID->requestKey(2) << "\", expect \"key 2\" and \"key 4\" ";
	if (thisID->requestKey(1)==k2 && thisID->requestKey(2)==k4)
	{		cout << "---------- PASSED" << endl;	}
	else
	{		cout << "---------- FAILED" << endl;	}

	printAttributes(thisID);


	cout << "\n--------------- <ID CLASS> Unit Test Completed -----------------\n\n" << endl;	


	cout << "\n--------------- <ID COLLECTION> Unit Test Begins -----------------\n\n" << endl;

	//-----------------------------------------------------------------
	cout << "TESTING // ID_collection Constructor ... " << endl;
	//-----------------------------------------------------------------
	ID_collection *C = new ID_collection; 
	cout << "\tCreating container C, pointer should not be NULL";
	if (C != NULL)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}

	//-----------------------------------------------------------------
	cout << "TESTING // addID() // getNumID() ... " << endl;
	//-----------------------------------------------------------------
	cout << "\tBefore adding ID, the ID ptr should be pointing to NULL and the number of IDs is [" << C->getNumID() <<"], expected [0]";
	ID* ptr = NULL;
	if (ptr == NULL && C->getNumID() == 0)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	ptr = C->addID();
	cout << "\tAfter adding 1st ID, the ID ptr should not be NULL and the number of IDs is [" << C->getNumID() <<"], expected [1]";
	if (ptr != NULL && C->getNumID() == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}

	ptr = C->addID();
	cout << "\tAfter adding 2nd ID, the ID ptr should not be NULL and the number of IDs is [" << C->getNumID() <<"], expected [2]";
	if (ptr != NULL && C->getNumID() == 2)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	
	ptr = C->addID();
	cout << "\tAfter adding 3rd ID, the ID ptr should not be NULL and the number of IDs is [" << C->getNumID() <<"], expected [3]";
	if (ptr != NULL && C->getNumID() == 3)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}


	//-----------------------------------------------------------------
	cout << "TESTING // removeID() [1/2] ... " << endl;
	//-----------------------------------------------------------------
	int removed = C->removeID(3);
	cout << "\tRemoved the 3rd ID, the returned value should be 1 and the number of IDs is [" << C->getNumID() << "], expected [2]";
	if (removed == 1 && C->getNumID() == 2)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}

	//-----------------------------------------------------------------
	cout << "TESTING // findID() ... " << endl;
	//-----------------------------------------------------------------	
	int found = -99;
	found = C->findID(0);
	cout << "\tAttempt to find ID ref no. is 0, the returned value is ["<< found <<"], expected [-1] ";
	if (found == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	found = C->findID(1);
	cout << "\tAttempt to find ID ref no. is 1, the returned value is ["<< found <<"], expected [0] ";
	if (found == 0)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	
	found = C->findID(2);
	cout << "\tAttempt to find ID ref no. is 2, the returned value is ["<< found <<"], expected [1] ";
	if (found == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	
	found = C->findID(3);
	cout << "\tAttempt to find ID ref no. is 3, the returned value is ["<< found <<"], expected -1] ";
	if (found == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}		

	//-----------------------------------------------------------------
	cout << "TESTING // setID() ... " << endl;
	//-----------------------------------------------------------------
	cout << "Setting 1st ID :" << endl;
	int set = C->setID(1,thisID);
	ptr = C->getID(1);
	
	cout << "\tSet thisID to the container's ref no. (1). \n" <<
			"\tThe return value is [" << set <<"], expected 1";
	if (set == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	
	string att0 = ptr->requestData("Name");
	cout <<"\tThe ID's Name attribute is \"" << att0 <<"\", expected \"thisiD\"";
	if (att0 == "thisID")
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}		
	
	string att1 = ptr->requestData("key 2");	
	cout <<"\tThe ID's key2 attribute is \"" << att1 <<"\", expected \"val 222\"";	
	if (att1 == "val 222")
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	


	C->setID(2,thatID);
	ptr = C->getID(2);
	cout << "\tSet thatID to the container's ref no. (2). \n" <<
			"\tThe return value is [" << set <<"], expected 1";
	if (set == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	
	att0 = ptr->requestData("Name");
	cout <<"\tThe ID's Name attribute is \"" << att0 <<"\", expected \"thatiD\"";
	if (att0 == "thatID")
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}		

	att1 = ptr->requestData("key 5");	
	cout <<"\tThe ID's key2 attribute is \"" << att1 <<"\", expected \"val 555\"";	
	if (att1 == "val 555")
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	



	//-----------------------------------------------------------------
	cout << "TESTING // getIDList ... " << endl;
	//-----------------------------------------------------------------
	vector<ID*> testList= C->getIDList();
	int listSize = testList.size(); 

	cout << "\tUsing getIDList function to copy data from C to testList. Number of elements that testList has is [" << listSize <<"], expected ["<< C->getNumID() <<"] ";
	if (listSize == C->getNumID())
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	
	cout << "\tConfirm that the 1st ID in testList is thisID";
	if (testList[0]->getIDref() == 1 && testList[0]->requestKey(0) == "Name" && testList[0]->requestData("Name") == "thisID")
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	cout << "\tConfirm that the 2nd ID in testList is thatID";
	if (testList[1]->getIDref() == 2 && testList[1]->requestKey(0) == "Name" && testList[1]->requestData("Name") == "thatID")
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}



	//-----------------------------------------------------------------
	cout << "TESTING // removeID() [2/2]... " << endl;
	//-----------------------------------------------------------------
	ID* ID4 = C->addID();
	ID* tempID4 = new ID(ID4->getIDref());
	*tempID4 = *ID4;

		// Add a new ID to the collection--------
		tempID4->setValue("Name", "ID4");
		string k7 = "key 7";
		string v7 = "val 777";
		tempID4->addAttribute(k7, v7);
		string k8 = "key 8";
		string v8 = "val 888";
		tempID4->addAttribute(k8, v8);
		//---------------------------------------
	C->setID(4, tempID4);

	ID* ID5 = C->addID();
	ID* tempID5 = new ID(ID5->getIDref());
	*tempID5 = *ID5;

		// Add a new ID to the collection--------
		tempID5->setValue("Name", "ID5");
		string k9 = "key 9";
		string v9 = "val 999";
		tempID5->addAttribute(k9, v9);
		string k10 = "key 10";
		string v10 = "val 101010";
		tempID5->addAttribute(k10, v10);
		//---------------------------------------
	C->setID(5,tempID5);

	// remove ID#2
	removed = C->removeID(2);
	cout <<"\tRemoved ID ref no. (2)..." << endl;
	// return 1
	cout <<"\t\tReturn value is [" << removed <<"], expected [1]";
	if (removed == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// num of ID
	cout <<"\t\tContainer number of ID is [" << C->getNumID() <<"], expected [3]";
	if (C->getNumID() == 3)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// findID(2) returns -1
	cout <<"\t\tAttempting to find ID #2, returns [" << C->findID(2) <<"], expected [-1]";
	if (C->findID(2) == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}

	// remove ID#4
	removed = C->removeID(4);
	cout <<"\tRemoved ID ref no. (4)..." << endl;
	// return 1
	cout <<"\t\tReturn value is [" << removed <<"], expected [1]";
	if (removed == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// num of ID
	cout <<"\t\tContainer number of ID is [" << C->getNumID() <<"], expected [2]";
	if (C->getNumID() == 2)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// findID(2) returns -1
	cout <<"\t\tAttempting to find ID #4, returns [" << C->findID(4) <<"], expected [-1]";
	if (C->findID(4) == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}

	// remove ID#1
	removed = C->removeID(1);
	cout <<"\tRemoved ID ref no. (1)..." << endl;
	// return 1
	cout <<"\t\tReturn value is [" << removed <<"], expected [1]";
	if (removed == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// num of ID
	cout <<"\t\tContainer number of ID is [" << C->getNumID() <<"], expected [1]";
	if (C->getNumID() == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// findID(2) returns -1
	cout <<"\t\tAttempting to find ID #2, returns [" << C->findID(1) <<"], expected [-1]";
	if (C->findID(1) == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	

	// remove ID#5
	removed = C->removeID(5);
	cout <<"\tRemoved ID ref no. (5)..." << endl;
	// return 1
	cout <<"\t\tReturn value is [" << removed <<"], expected [1]";
	if (removed == 1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// num of ID
	cout <<"\t\tContainer number of ID is [" << C->getNumID() <<"], expected [0]";
	if (C->getNumID() == 0)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// findID(2) returns -1
	cout <<"\t\tAttempting to find ID #5, returns [" << C->findID(5) <<"], expected [-1]";
	if (C->findID(5) == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}	


	// remove ID#5
	removed = C->removeID(1);
	cout <<"\tAttempting to removed ID ref no. (1)..." << endl;
	// return 1
	cout <<"\t\tReturn value is [" << removed <<"], expected [-1]";
	if (removed == -1)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}
	// num of ID
	cout <<"\t\tContainer number of ID is [" << C->getNumID() <<"], expected [0]";
	if (C->getNumID() == 0)
		{	cout << "----------- PASSED" << endl;	}
	else
		{	cout << "----------- FAILED" << endl;	}

	cout << "\n--------------- <ID COLLECTION> Unit Test Completed -----------------\n\n" << endl;	

	return 0;
}