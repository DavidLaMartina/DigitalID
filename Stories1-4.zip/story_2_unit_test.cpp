/*********************************************************************
* Program: Digital ID - Unit tests for Story #2
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: 	Unit tests for Story #2, a plain-text prototype for adding new ID to collection
*********************************************************************/

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include "ID_collection.B.hpp"

using namespace std;


// Print All attributes for this ID
void printAttributes(ID* thisID)
{
	vector<string> keys = thisID->requestDataMap();
	cout << "\t\tThis ID has [" <<  thisID->getNumAttributes() <<"] attributes: " << endl;
	for (int j = 0; j < thisID->getNumAttributes(); j++)
	{
		cout << "\t\t["<< j << "] > \"" << keys[j] << "\" : \"" << thisID->requestData(keys[j]) << "\"" << endl ;
	}
	cout << endl;
}

// Print All the stats and data in ID container
void printState(vector<ID*> V, int num_ID)
{

	cout << "\n\n----- Container has [" << num_ID << "] ----------------- \n" << endl;
	for (int i = 0; i < num_ID; i++)
	{
		cout << "\t+ [" << i << "]\tRef-no.\t" << V[i]->getIDref() << " : " << endl;
		printAttributes(V[i]);
	}
}
// Parse string input to integer
// Credit to Luka Marinko at
//  https://stackoverflow.com/questions/194465/how-to-parse-a-string-to-an-int-in-c
int string_to_int(string input){
    stringstream stream(input);
    int num;
    if ((stream >> num).fail()){
        // We know we need positive input - return -1 as sentinel value if parse fails
        return -1;
    }
    else{
        return num;
    }
}

int menu()
{
	cout << endl;
	cout << "------------------------------" << endl;
	cout << "-- Menu-----------------------" << endl;
	cout << "_/	" << endl;
	cout << "\t1. Add ID " << endl;
	cout << "\t2. Update ID " << endl;
	cout << "\t3. Remove ID " << endl;
	cout << "\t4. Exit "	<< endl;
	cout << " " << endl;

	string input = " ";
	bool valid = false;
	int choice = 0;
	while (valid == false)
	{
		cout << "[?]Please enter \"1\", \"2\", \"3\", or \"4\": " ;
		getline(cin, input);

		if (input == "1")
		{
			choice = 1;
			valid = true;
		}
		else if (input == "2")
		{
			choice = 2;
			valid = true;
		}
		else if (input == "3"){
            choice = 3;
            valid = true;
		}
		else if (input == "4"){
            choice = 4;
            valid = true;
		}
		else
		{
			cout << "Input Invalid! Try again..." << endl;
		}
	}
	return choice;
}

void create_ID(ID_collection * C)
{
	ID* newID = C->addID();
	ID* tempID = new ID(newID->getIDref());

	string input1 = "";
	string input2 = "";
	*tempID = *newID;
	bool done = false;
	bool valid = false;

	// Set the name
	cout << "[?]What ID is this? : ";
	getline(cin, input1);
	tempID->setValue("Name", input1);

	// Add attribute
	while (!done)
	{
		valid = false;
		cout << "Please enter ID attribute(s). \n[?]Key : " ;

		getline(cin, input1);

		cout << "[?]Value : ";

		getline(cin, input2);
		tempID->addAttribute(input1, input2);

		cout << "Added [" << input1 << " : " << input2 << "] to the ID data." << endl;

		while (!valid)
		{
			printAttributes(tempID);
			cout << "\n[?]Continue to add more attribute? Enter \"Y\" or \"N\" : " ;

			getline(cin, input1);
			if (input1 == "Y" || input1 == "y")
			{
				valid = true;
			}
			else if (input1 == "N" || input1 == "n")
			{
				valid = true;
				done = true;
			}
			else
			{
				cout << "Invalid input! Please try again...";
			}
		}
	}

	C->setID(newID->getIDref(),tempID);
}
void update_ID(ID_collection * C){

    string input1 = "";
    string input2 = "";
    int choice;
    ID* existing_ID;
    ID* to_update;
    bool done = false;
    bool valid = false;
    bool complete = false;

    cout << "[?]Which ID do you want to update? Enter one of the reference numbers listed above. \n[?]Reference: ";

    // Continue attempting to get user choice until choose valid ID
    while (!valid){
        getline(cin, input1);
        choice = string_to_int(input1);
        if (choice > 0 && C->getID(choice) != nullptr){
            valid = true;
        }
        else{
            cout << "Invalid input. Type the reference number of an existing ID. ";
        }
    }
    // Get relevant ID
    /* Change this code in the next session to grab a COPY of the existing ID, update that copy, and
       finally set it to the relevant pointer in the collection's ID* vector. */
    to_update = C->getID(choice);

    // Allow user to edit ID attributes until done
    while (!done){
        // Display existing attributes before change
        printAttributes(to_update);

        // Allow user to choose next action - change value of attribute, delete attribute, add attribute
        valid = false;
        cout << "[?]What do you want to do with the ID?" << endl;
        cout << "\t1. Update attribute " << endl;
        cout << "\t2. Delete attribute " << endl;
        cout << "\t3. Add attribute " << endl;
        cout << "\t4. Nothing - done "	<< endl;

        cout << "[?]Please enter \"1\", \"2\", \"3\", or \"4\": " ;
        while (!valid){
            getline(cin, input1);

            if (input1 == "1"){
                valid = true;
                choice = 1;
            }
            else if (input1 == "2"){
                valid = true;
                choice = 2;
            }
            else if (input1 == "3"){
                valid = true;
                choice = 3;
            }
            else if (input1 == "4"){
                valid = true;
                choice = 4;
            }
            else{
                cout << "Invalid input! Try again...";
            }
        }
        // Allow user to perform specified action
        switch(choice){
            // Update attribute
            case 1:{
                valid = false;
                cout << "[?]Which attribute do you want to change? Input its 0-index referenced number: " << endl;
                while (!valid){
                    getline(cin, input1);
                    choice = string_to_int(input1);
                    if (choice >= 0 && choice < to_update->getNumAttributes()){
                        valid = true;
                    }
                    else{
                        cout << "Invalid input. Try again! " << endl;
                    }
                }
                cout << "Changing attribute " << to_update->requestKey(choice) << ". What value do you want to set? " << endl;
                getline(cin, input1);
                int success = to_update->setValue(to_update->requestKey(choice), input1);
                if (success > 0){
                    cout << "...Value changed to " << input1 << endl;
                }
                else{
                    cout << "Value change failed." << endl;
                }
                break;
            }
            // Delete attribute
            case 2:{
                valid = false;
                cout << "[?]Which attribute do you want to delete? Input its 0-indexed reference number: ";
                while (!valid){
                    getline(cin, input1);
                    choice = string_to_int(input1);
                    if (choice >= 0 && choice < to_update->getNumAttributes()){
                        valid = true;
                    }
                    else{
                        cout << "Invalid input. Try again! " << endl;
                    }
                }
                cout << "Removing attribute " << to_update->requestKey(choice) << "..." << endl;
                complete = to_update->removeAttribute(to_update->requestKey(choice));
                if (complete){
                    cout << "Attribute removed." << endl;
                }
                else{
                    cout << "Attribute removal failed." << endl;
                }
                break;
            }
            // Add new attribute
            case 3:{
                cout << "Please enter ID attribute. \n[?]Key : " ;

                getline(cin, input1);

                cout << "[?]Value : ";

                getline(cin, input2);
                to_update->addAttribute(input1, input2);

                cout << "Added [" << input1 << " : " << input2 << "] to the ID data." << endl;

                break;
            }
            // Nothing - quit
            case 4:{
                done = true;
                break;
            }
            default:{
                done = true;
                break;
            }
        }
    }
    // C->setID(to_update->getIDref(), to_update);
}
void remove_ID(ID_collection * C){
    string input1 = "";
    string input2 = "";
    int choice;
    ID* existing_ID;
    ID* to_update;
    bool done = false;
    bool valid = false;
    bool complete = false;

    cout << "[?]Which ID do you want to remove? Enter one of the reference numbers listed above. \n[?]Reference: ";

    // Continue attempting to get user choice until choose valid ID
    while (!valid){
        getline(cin, input1);
        choice = string_to_int(input1);
        if (choice > 0 && C->getID(choice) != nullptr){
            valid = true;
        }
        else{
            cout << "Invalid input. Type the reference number of an existing ID. ";
        }
    }
    cout << "Removing ID " << choice << "..." << endl;
    int success = C->removeID(choice);
    if (success > 0){
        cout << "ID successfully removed." << endl;
    }
    else{
        cout << "ID removal failed." << endl;
    }
}

int main()
{
	cout << "\n--------------- <Stories 2> Unit Test Begins -----------------\n\n" << endl;
	ID_collection *C = new ID_collection;
	while(1 || 2 || 3)
	{
		// Prompt main menu
		int choice = menu();

		// Quit program
		if (choice == 4)
		{
			break;
		}
		switch(choice){
            case 1:{
                // Create ID procedure
                create_ID(C);

                // Print All the stats and data in ID container
                printState(C->getIDList(), C->getNumID());

                break;
            }
            case 2:{
                // Make sure there are actually IDs to update...
                if (C->getNumID() <= 0){
                    cout << "There are no IDs to update yet. Add at least one ID." << endl;
                    break;
                }
                else{
                    // Update ID
                    update_ID(C);
                }
                // Print All the stats and data in ID container
                printState(C->getIDList(), C->getNumID());

                break;
            }
            case 3:{
                // Make sure there are actually IDs to remove...
                if (C->getNumID() <= 0){
                    cout << "There are no IDs to remove yet. Add at least one ID." << endl;
                    break;
                }
                else{
                    // Remove ID
                    remove_ID(C);
                }
                // Print All the stats and data in ID container
                printState(C->getIDList(), C->getNumID());

                break;
            }
		}
	}
	cout << "\n--------------- <Story 2> Unit Test Completed -----------------\n\n" << endl;
	return 0;
}
