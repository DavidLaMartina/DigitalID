/*********************************************************************  
* Program: Digital ID - ID Collection Class for Story #1 and #2
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   	 malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: 	ID Collection class keeps a container of IDs, 
*				public functions for managing the container
*********************************************************************/

#ifndef	ID_COLLECTION_B_HPP
#define ID_COLLECTION_B_HPP
#include <string>
#include "ID_class.B.hpp"

using namespace std;

class ID_collection
{
	protected:
		int num_ID;
		int nextRefNum;
		vector<ID*> myCollection;
		
	public:	
		ID_collection();			// Constructor of a collection class object
		int getNumID();				// Get the number of IDs
		ID* getID(int);				// Get the ID pointer by ID reference number
		int setID(int, ID*);		// Update a piece of existing ID with the pointer to an updated copy
		int removeID(int);			// Remove an ID from the collection
		ID* addID();				// Add a new ID to the collection (empty)
		int findID(int);			// Get the index of the vector that contains ID, search by the ID reference number
		vector<ID*> getIDList();	// Return the collection of IDs as a whole vector
		int getNextRef();			// Generate the next available ref number for ID (currently a mockup function)
		bool authenticate(ID*);		// Authenticate the passed in ID (currently a mockup function)
		~ID_collection();			// Deconstructor
};


#endif
