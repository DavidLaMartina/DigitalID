/**************************************************************************************************
* Program: Digital ID - Unit tests for ID Collection class
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: Unit tests to ensure ID collection class functions are working properly
**************************************************************************************************/

#include "ID_collection.hpp"
#include "ID_class.hpp"

#include <iostream>
using std::cout;
using std::endl;

#include <string>
using std::string;
// using std::to_string;

#include <vector>
using std::vector;

#include <sstream>
using std::stringstream;

// Unit test helper prototypes
void printBorder();
string verifyString(string, string);
string verifyInt(int, int);
string verifyBool(bool);
void verifyStringPrint(string, string);
void verifyIntPrint(int, int);
void verifyBoolPrint(bool);


// String conversion - credit to Nemo on Stack Overflow
// https://stackoverflow.com/questions/5590381/easiest-way-to-convert-int-to-string-in-c
string to_string(int num){
    stringstream ss;
    ss << num;
    string str = ss.str();
    return str;
}

int main(int argc, char*argv[])
{
    /* Constructor tests */
    ID_collection* collection = new ID_collection();

    printBorder();
    cout << "Constructor tests..." << endl << endl;
    if (collection){
        cout << "The new ID collection was created." << endl;
        cout << "ID counter: (should be zero): " << collection->getIDCount() << verifyInt(collection->getIDCount(), 0) << endl;
    }
    else{
        cout << "The new ID collection is null." << endl;
    }
    printBorder();
    cout << endl;

    /* ID-adding tests */
    string test_ref_1 = "abc123";
    string test_ref_2 = "def456";
    string test_ref_3 = "ghi789";
    ID* test_id_1 = collection->addID(test_ref_1);
    ID* test_id_2 = collection->addID(test_ref_2);
    ID* test_id_3 = collection->addID(test_ref_3);

    printBorder();
    cout << "ID-adding tests" << endl << endl;
    if (test_id_1 && test_id_2 && test_id_3){
        cout << "The IDs were created successfully." << verifyBool(test_id_1 && test_id_2 && test_id_3) << endl;
        cout << "Adding ID generic attributes to test IDs..." << endl;
        for (int i = 0; i < 5; i++){
            string test_key_1 = "key_" + to_string(i + 1);
            string test_value_1 = "val_" + to_string(i + 1);
            string test_key_2 = "key_" + to_string(i + 6);
            string test_value_2 = "val_" + to_string(i + 6);
            string test_key_3 = "key_" + to_string(i + 11);
            string test_value_3 = "val_" + to_string(i + 11);
            test_id_1->addAttribute(test_key_1, test_value_1);
            test_id_2->addAttribute(test_key_2, test_value_2);
            test_id_3->addAttribute(test_key_3, test_value_3);
        }
        cout << "Setting IDs into collection vector using collection's setID method..." << endl;
        collection->setID(test_id_1);
        collection->setID(test_id_2);
        collection->setID(test_id_3);

        cout << "Setting test pointers to created IDs via collection's getID method..." << endl;
        ID* ID_1_ptr = collection->getID("abc123");
        ID* ID_2_ptr = collection->getID("def456");
        ID* ID_3_ptr = collection->getID("ghi789");

        cout << "These IDs' keys and values, retrieved through those pointers, are..." << endl;
        vector<string> ID_1_keys = ID_1_ptr->requestDataMap();
        vector<string> ID_2_keys = ID_2_ptr->requestDataMap();
        vector<string> ID_3_keys = ID_3_ptr->requestDataMap();

        cout << endl << "ID 1 keys and values..." << endl;
        for (int i = 0; i < ID_1_ptr->getNumAttributes(); i++){
            string verify_key = "key_" + to_string(i + 1);
            cout << ID_1_keys[i] << verifyString(ID_1_keys[i], verify_key) << endl;
        }
        cout << endl;
        for (int i = 0; i < ID_1_ptr->getNumAttributes(); i++){
            string verify_val = "val_" + to_string(i + 1);
            cout << ID_1_ptr->requestData(ID_1_keys[i]) << verifyString(ID_1_ptr->requestData(ID_1_keys[i]), verify_val) << endl;
        }
        cout << endl;
        cout << "ID 2 keys and values..." << endl;
        for (int i = 0; i < ID_2_ptr->getNumAttributes(); i++){
            string verify_key = "key_" + to_string(i + 6);
            cout << ID_2_keys[i] << verifyString(ID_2_keys[i], verify_key) << endl;
        }
        cout << endl;
        for (int i = 0; i < ID_2_ptr->getNumAttributes(); i++){
            string verify_val = "val_" + to_string(i + 6);
            cout << ID_2_ptr->requestData(ID_2_keys[i]) << verifyString(ID_2_ptr->requestData(ID_2_keys[i]), verify_val) << endl;
        }
        cout << endl;
        cout << "ID 3 keys and values..." << endl;
        for (int i = 0; i < ID_3_ptr->getNumAttributes(); i++){
            string verify_key = "key_" + to_string(i + 11);
            cout << ID_3_keys[i] << verifyString(ID_3_keys[i], verify_key) << endl;
        }
        cout << endl;
        for (int i = 0; i < ID_3_ptr->getNumAttributes(); i++){
            string verify_val = "val_" + to_string(i + 11);
            cout << ID_3_ptr->requestData(ID_3_keys[i]) << verifyString(ID_3_ptr->requestData(ID_3_keys[i]), verify_val) << endl;
        }
        cout << endl;

        /* Testing getIDCount */
        cout << "The collection's ID count is: " << collection->getIDCount() << verifyInt(collection->getIDCount(), 3) << endl << endl;

        /* Testing addition of already-added IDs */
        printBorder();
        cout << "Testing the addition and setting of IDs whose reference numbers were already added" << endl << endl;
        cout << "Attempting to add an ID with the same unique identifier (abc123) as ID 1..." << endl;
        ID* test_duplicate_1 = collection->addID(test_ref_1);
        cout << "The ID count is now (should not have changed): " << collection->getIDCount() << verifyInt(collection->getIDCount(), 3) << endl << endl;

        cout << "Attempting to manipulate data via pointer set to ID with pre-existing identifier - values should all be new..." << endl;
        cout << "Adding attributes and setting pointer..." << endl;
        for (int i = 0; i < 5; i++){
            string new_key = "new_key_" + to_string(i + 1);
            string new_val = "new_val_" + to_string(i + 1);
            test_duplicate_1->addAttribute(new_key, new_val);
        }
        collection->setID(test_duplicate_1);
        cout << "Retrieving re-set ID and associated data map via collection's getID method..." << endl << endl;
        vector<string> new_ID_1_keys = collection->getIDList()[0]->requestDataMap();

        cout << "ID 1's keys and values are now..." << endl;
        for (int i = 0; i < test_duplicate_1->getNumAttributes(); i++){\
            string verify_key = "new_key_" + to_string(i + 1);
            cout << new_ID_1_keys[i] << verifyString(verify_key, new_ID_1_keys[i]) << endl;
        }
        cout << endl;
        for (int i = 0; i < test_duplicate_1->getNumAttributes(); i++){
            string verify_val = "new_val_" + to_string(i + 1);
            cout << test_duplicate_1->requestData(new_ID_1_keys[i]) << verifyString(test_duplicate_1->requestData(new_ID_1_keys[i]), verify_val) << endl;
        }
        cout << endl;
        cout << "The total number of IDs is now (still should not have changed): " << collection->getIDCount() << verifyInt(collection->getIDCount(), 3) << endl << endl;
    }
    else{
        cout << "The IDs are null." << endl;
        return 0;
    }
    printBorder();
    cout << "ID removal tests" << endl << endl;
    cout << "Removing second ID from collection..." << endl;
    collection->removeID("def456");
    cout << "The number of IDs in the collection is now..." << collection->getIDCount() << verifyInt(collection->getIDCount(), 2) << endl << endl;

    vector<ID*> remain_ID_list = collection->getIDList();
    ID* remain_ID_1 = remain_ID_list[0];
    ID* remain_ID_2 = remain_ID_list[1];
    vector<string> remain_keys_1 = remain_ID_1->requestDataMap();
    vector<string> remain_keys_2 = remain_ID_2->requestDataMap();
    cout << "Testing that the middle ID was removed properly..." << endl;
    cout << "The remaining IDs' reference numbers, keys and values are..." << endl << endl;

    cout << "ID 1 reference: " << remain_ID_1->getIDref() << verifyString(remain_ID_1->getIDref(), "abc123") << endl;
    for (int i = 0; i < remain_ID_1->getNumAttributes(); i++){
            string verify_key = "new_key_" + to_string(i + 1);
            cout << remain_keys_1[i] << verifyString(remain_keys_1[i], verify_key) << endl;
    }
    cout << endl;
    for (int i = 0; i < remain_ID_1->getNumAttributes(); i++){
        string verify_val = "new_val_" + to_string(i + 1);
        cout << remain_ID_1->requestData(remain_keys_1[i]) << verifyString(remain_ID_1->requestData(remain_keys_1[i]), verify_val) << endl;
    }
    cout << endl;
    cout << "ID 2 reference: " << remain_ID_2->getIDref() << verifyString(remain_ID_2->getIDref(), "ghi789") << endl;
    for (int i = 0; i < remain_ID_2->getNumAttributes(); i++){
        string verify_key = "key_" + to_string(i + 11);
        cout << remain_keys_2[i] << verifyString(remain_keys_2[i], verify_key) << endl;
    }
    cout << endl;
    for (int i = 0; i < remain_ID_2->getNumAttributes(); i++){
        string verify_val = "val_" + to_string(i + 11);
        cout << remain_ID_2->requestData(remain_keys_2[i]) << verifyString(remain_ID_2->requestData(remain_keys_2[i]), verify_val) << endl;
    }
    printBorder();
    cout << endl;

    return 0;
}

/* Border-printing function for separating tests */
void printBorder(){
    for (int i = 0; i < 100; i++){
        cout << "*";
    }
    cout << endl;
}
/* Examines whether 2 strings are identical.
   If so, prints SUCCESS. If not, prints FAIL */
string verifyString(string string_1, string string_2){
    if (string_1 == string_2){
        return " ...SUCCESS ";
    }
    else{
        return " ...FAIL ";
    }
}
void verifyStringPrint(string string_1, string string_2){
    if (string_1 == string_2){
        cout <<  " ...SUCCESS ";
    }
    else{
        cout <<  " ...FAIL ";
    }
}
/* Examines whether 2 integers are identical.
   If so, prints SUCCESS. If not, prints FAIL */
string verifyInt(int int_1, int int_2){
    if (int_1 == int_2){
        return " ...SUCCESS ";
    }
    else{
        return " ...FAIL ";
    }
}
void verifyIntPrint(int int_1, int int_2){
    if (int_1 == int_2){
        cout <<  " ...SUCCESS ";
    }
    else{
        cout <<  " ...FAIL ";
    }
}
/* Examines whether statement is true.
   If so, prints SUCCESS. If not, prints FAIL */
string verifyBool(bool expression){
    if (expression){
        return " ...SUCCESS ";
    }
    else{
        return " ...FAIL ";
    }
}
void verifyBoolPrint(bool expression){
    if (expression){
        cout << " ...SUCCESS ";
    }
    else{
        cout << " ...FAIL";
    }
}
