/**************************************************************************************************
* Program: Digital ID -
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description:
**************************************************************************************************/

#include "ID_class.hpp"

#include <iostream>
using std::cout;
using std::endl;

#include <string>
using std::string;
// using std::to_string;

#include <vector>
using std::vector;

#include <ctime>
using std::time;
using std::time_t;
using std::tm;
using std::localtime;


/* Just initializes the number of attributes to 0;
 *  doesn't add anything to the list */
ID::ID(string ID_ref){
    num_ID_attributes = 0;                          // Start #attributes at 0
    auth_interval = DEFAULT_AUTH_INTERVAL;          // default to DEFAULT value
    ID_reference_number = ID_ref;                   // Set reference ID to argument
    init_date = getCurrentDateTime();               // Set initialization date to current date & time
    last_auth = init_date;                          // Start "last" authentication as init date
}
/* Constructor that takes authentication interval */
ID::ID(string ID_ref, int _auth_int){
    num_ID_attributes = 0;
    auth_interval = _auth_int;
    ID_reference_number = ID_ref;
    init_date = getCurrentDateTime();
    last_auth = init_date;
}

/* Getters */
string ID::getIDref(){
    return ID_reference_number;
}
DateTime ID::getInitDate(){
    return init_date;
}
DateTime ID::getLastAuth(){
    return last_auth;
}
int ID::getAuthInterval(){
    return auth_interval;
}
int ID::getNumAttributes(){
    return num_ID_attributes;
}

/* requestData
 * Parameters:      string key
 * Return:          string value
 *
 * Description: Retrieve value by key */
string ID::requestData (string key){
    string val = "";
    for (int i = 0; i < num_ID_attributes; i++){
        if (ID_attributes[i].key == key){
            val = ID_attributes[i].value;
        }
    }
    return val;
}

/* requestDataMap
 * Parameters:
 * Return:          vector<string> keys
 *
 * Description: Retrieves all keys in the ID */
vector<string> ID::requestDataMap(){
    vector<string> map;
    for (int i = 0; i < num_ID_attributes; i++){
        map.push_back(ID_attributes[i].key);
    }
    return map;
}

/* addAttribute
 * Parameters:      string key, string value
 * Return:          value added to data map (void function)
 *
 * Description: Adds a key-value pair to the data map
 *  and increments the number of attributes */
void ID::addAttribute(string key, string value){
    ID_attributes.push_back(IDMap_data(key, value));
    num_ID_attributes++;
}

/* removeAttribute
 * Parameters:      string key
 * Return:          true if success, else false
 *
 * Description: Removes a key-value pair from the ID object
 *  if it exists...returns false if it does not exist. Decrements
 *  the number of attributes. */
bool ID::removeAttribute(string key){
    for (int i = 0; i < num_ID_attributes; i++){
        if (ID_attributes[i].key == key){
            ID_attributes.erase(ID_attributes.begin() + i);
            num_ID_attributes--;
            return true;
        }
    }
    // Return false if get to the end of loop - key does not exist
    return false;
}

/* requestAuthentication
 * Parameters:
 * Return:          true if approved, else false
 *
 * Description: Use authentication manager function to authenticate
 *  this piece of ID */
bool ID::requestAuthentication(){
    return true;
}

DateTime ID::getCurrentDateTime(){
    time_t t = time(0); // get time now
    tm* now = localtime(&t);

    DateTime date_now;
    date_now.year = now->tm_year + 1990;    // tm format requires adding 1990...
    date_now.month = now->tm_mon + 1;       // also requires adding 1 to month
    date_now.day = now->tm_mday;
    date_now.hour = now->tm_hour;
    date_now.minutes = now->tm_min;

    return date_now;
}

/* Deconstructor */
ID::~ID(){}
