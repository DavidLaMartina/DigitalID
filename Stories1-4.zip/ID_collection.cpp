/**************************************************************************************************
* Program: Digital ID -
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description:
**************************************************************************************************/

#include "ID_collection.hpp"
#include "ID_class.hpp"

#include <iostream>
using std::cout;
using std::endl;

#include <string>
using std::string;

#include <vector>
using std::vector;

/* ID collection constructor - only need to initialize
   tracking variables */
ID_collection::ID_collection()
{
    num_ID = 0;
    nextRefNum = 1;
}

/* Getters */
int ID_collection::getIDCount(){
    return num_ID;
}

/* GetID
 * Parameters:      unique identifier (string)
 * Returns:         ID object pointer or NULL
 *
 * Description: Get ID pointer by the reference number of user ID.
 *  Use Find ID function to get index in ID list first, then retrieve
 *  that pointer and return it. */
ID* ID_collection::getID(string ID_ref){
    int ID_index =  findID(ID_ref);
    if (ID_index >= 0){
        return myCollection[ID_index];
    }
    else{
        return nullptr;
    }
}

/* SetID
 * Parameters:      unique identifier, ID* thisUpdateID
 * Return:          int 1 if success
                        -1 if id reference not found
                        -2 if ID not valid (not authenticated)
 *
 * Description: Assuming data was validated, and ID does exist,
 *  function sets data to existing ID. Use Get ID function to get
 *  the object pointer, or check for NULL if it exists. */
int ID_collection::setID(ID* thisUpdateID){
    // Authenticate the updated data - if true, set...assuming valid
    //  ***Change this function upon validation implementation
    bool valid_ID = true;

    if (valid_ID){
        ID* set_pointer = getID(thisUpdateID->ID_reference_number);
        // If there is no pointer set aside for this ID, return -1 (error)
        if (!set_pointer){
            return -1;
        }
        // Else assign that pointer to the updated object
        else{
            // Get the appropriate index, which references a pointer to the ID
            // ***This change necessary due to inability to change pointer value when
            //  passed by value
            int update_index = findID(thisUpdateID->ID_reference_number);
            myCollection[update_index] = thisUpdateID;

            // set_pointer = thisUpdateID;
            return 1;
        }
    }
    else{
        return -2;
    }
}

/* removeID
 * Parameters:      unique identifier
 * Returns:         int 1 if successfully removed
                        -1 if does not exist
 *
 * Description: Removes ID object from collection by reference of
 * the ID. Decrements number of IDs. Return 1 if successfully removed,
 * -1 if ID doesn't exist. */
int ID_collection::removeID(string ID_ref){
    int ID_index = findID(ID_ref);
    if (ID_index >= 0){
        delete myCollection[ID_index];
        myCollection.erase(myCollection.begin() + ID_index);
        num_ID--;
        return 1;
    }
    else{
        return -1;
    }
}

/* create ID
 * Parameters:      unique identifier (decided by calling class / function)
 * Return           ID pointer
 *
 * Description: Creates empty data ID and returns the ID pointer. */
ID* ID_collection::addID(string ID_ref){
    // Instantiate new ID object
    ID* new_ID_ptr = new ID(ID_ref);

    // Determine whether another ID object with this unique identifier
    // already exists...if it does NOT, create necessary space in the collection
    int ID_index = findID(ID_ref);
    if (ID_index < 0){
        myCollection.push_back(new_ID_ptr);
        num_ID++;
    }
    // Return pointer to new ID object to be used in add or update
    return new_ID_ptr;
}

/* Get ID list
 * Parameters:
 * Return:          myCollection (ID* vector)
 *
 * Description: Returns the collection */
vector<ID*> ID_collection::getIDList(){
    return myCollection;
}

/* get next reference number
 * Parameters:
 * Return:          int newRefNum
 *
 * Description: Generate an available (unique) reference number.
 *  Returns the number. This is a mockup function. */
int ID_collection::getNextRefNum(){
    int num = nextRefNum;
    nextRefNum++;
    return num;
}

/* Find ID
 * Parameters:      string ID reference
 * Return:          int index of vector for that particular ID OR
                        -1 if the index doesn't exist
 *
 * Description: Searches through list to find matching refence string
 *  of the ID. Returns the index in the vector. */
int ID_collection::findID(string ID_ref){
    for (int i = 0; i < num_ID; i++){
        if (myCollection[i]->ID_reference_number == ID_ref){
            return i;
        }
    }
    return -1;
}

ID_collection::~ID_collection(){}








