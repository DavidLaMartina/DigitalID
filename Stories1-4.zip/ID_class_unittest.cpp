/**************************************************************************************************
* Program: Digital ID - Unit tests for ID class
* Author: Group 34
* Email: lamartid@oregonstate.edu, tsuio@oregonstate.edu,
*   malicayl@oregonstate.edu, cwiklow@oregonstate.edu
* Date: 11/25/2018
* Description: Unit tests to ensure ID class functions are working properly
**************************************************************************************************/

#include "ID_class.hpp"

#include <iostream>
using std::cout;
using std::endl;

#include <string>
using std::string;
//using std::to_string;

#include <vector>
using std::vector;

#include <sstream>
using std::stringstream;

// Unit test helper prototypes
void printBorder();
string verifyString(string, string);
string verifyInt(int, int);
string verifyBool(bool);
void verifyStringPrint(string, string);
void verifyIntPrint(int, int);
void verifyBoolPrint(bool);

// String conversion - credit to Nemo on Stack Overflow
// https://stackoverflow.com/questions/5590381/easiest-way-to-convert-int-to-string-in-c
string to_string(int num){
    stringstream ss;
    ss << num;
    string str = ss.str();
    return str;
}

int main(int argc, char*argv[])
{
    /* Constructor tests */
    string test_ref = "abc123";
    int test_auth_interval = 6;
    ID* new_ID_ptr_1 = new ID(test_ref);
    ID* new_ID_ptr_2 = new ID(test_ref, test_auth_interval);

    printBorder();

    cout << "Constructor and getter tests..." << endl << endl;

    if (new_ID_ptr_1){
        cout << "The ID with the basic constructor was created." << verifyBool(new_ID_ptr_1) << endl;
        cout << "Reference #: " << new_ID_ptr_1->getIDref() << verifyString(new_ID_ptr_1->getIDref(), "abc123") << endl;
        cout << "Authentication interval: " << new_ID_ptr_1->getAuthInterval() << verifyInt(new_ID_ptr_1->getAuthInterval(), 7) << endl;
        cout << "Starting number of attributes: " << new_ID_ptr_1->getNumAttributes() << verifyInt(new_ID_ptr_1->getNumAttributes(), 0) << endl << endl;
        cout << "Init date - should be current date & time: \n" << new_ID_ptr_1->getInitDate().year << "\n"
                               << new_ID_ptr_1->getInitDate().month << "\n"
                               << new_ID_ptr_1->getInitDate().day << "\n"
                               << new_ID_ptr_1->getInitDate().hour << "\n"
                               << new_ID_ptr_1->getInitDate().minutes << endl;
        cout << "Last auth - should be equal to init date: " << new_ID_ptr_1->getLastAuth().year << "\n"
                              << new_ID_ptr_1->getLastAuth().month << "\n"
                              << new_ID_ptr_1->getLastAuth().day << "\n"
                              << new_ID_ptr_1->getLastAuth().hour << "\n"
                              << new_ID_ptr_1->getLastAuth().minutes << endl;
    }
    else{
        cout << "The ID with the basic constructor was null." << endl;
    }

    cout << endl;

    if (new_ID_ptr_2){
        cout << "The ID with the 2-argument constructor was created." << verifyBool(new_ID_ptr_2) << endl;
        cout << "Reference #: " << new_ID_ptr_2->getIDref() << verifyString(new_ID_ptr_2->getIDref(), "abc123") << endl;
        cout << "Authentication interval: " << new_ID_ptr_2->getAuthInterval() << verifyInt(new_ID_ptr_2->getAuthInterval(), 6) << endl;
        cout << "Starting number of attributes: " << new_ID_ptr_2->getNumAttributes() << verifyInt(new_ID_ptr_2->getNumAttributes(), 0) << endl << endl;
        cout << "Init date - should be current date & time: \n" << new_ID_ptr_2->getInitDate().year << "\n"
                               << new_ID_ptr_2->getInitDate().month << "\n"
                               << new_ID_ptr_2->getInitDate().day << "\n"
                               << new_ID_ptr_2->getInitDate().hour << "\n"
                               << new_ID_ptr_2->getInitDate().minutes << endl;
        cout << "Last auth - should be equal to init date: " << new_ID_ptr_2->getLastAuth().year << "\n"
                              << new_ID_ptr_2->getLastAuth().month << "\n"
                              << new_ID_ptr_2->getLastAuth().day << "\n"
                              << new_ID_ptr_2->getLastAuth().hour << "\n"
                              << new_ID_ptr_2->getLastAuth().minutes << endl;
    }
    else{
        cout << "The ID with the 2-argument constructor was null." << endl;
    }
    printBorder();

    /* Attribute adding and removal tests */
    cout << "Attribute adding and removal tests..." << endl;
    cout << endl;

    cout << "Adding attributes key_1 through key_10 with values value_1 through value_10..." << endl << endl;
    for (int i = 0; i < 10; i++){
        string key_string = "key_" + to_string(i + 1);
        string value_string = "value_" + to_string(i + 1);
        new_ID_ptr_1->addAttribute(key_string, value_string);
    }
    vector<string> keys = new_ID_ptr_1->requestDataMap();
    cout << "All of the keys in the ID are:" << endl;
    for (int i = 0; i < new_ID_ptr_1->getNumAttributes(); i++){
        string verify_key = "key_" + to_string(i + 1);
        cout << keys[i] << verifyString(keys[i], verify_key) << endl;
    }
    cout << endl;
    cout << "All of the values in the ID are:" << endl;
    for (int i = 0; i < new_ID_ptr_1->getNumAttributes(); i++){
        string verify_val = "value_" + to_string(i + 1);
        cout << new_ID_ptr_1->requestData(keys[i]) << verifyString(new_ID_ptr_1->requestData(keys[i]), verify_val) << endl;
    }
    cout << endl;
    cout << "Removing key / value pairs 3 and 7..." << endl;
    new_ID_ptr_1->removeAttribute("key_3");
    new_ID_ptr_1->removeAttribute("key_7");
    cout << "There are now " << new_ID_ptr_1->getNumAttributes() << " key-value pairs in the ID." << verifyInt(new_ID_ptr_1->getNumAttributes(), 8) << endl;

    keys = new_ID_ptr_1->requestDataMap();
    cout << "Now all of the keys and values are..." << endl;
    for (int i = 0; i < new_ID_ptr_1->getNumAttributes(); i++){
        string verify_key;
        if (i < 2){
            verify_key = "key_" + to_string(i + 1);
        }
        else if (i < 5){
            verify_key = "key_" + to_string(i + 2);
        }
        else{
            verify_key = "key_" + to_string(i + 3);
        }
        cout << keys[i] << verifyString(keys[i], verify_key) << endl;
    }
    cout << endl;
    for (int i = 0; i < new_ID_ptr_1->getNumAttributes(); i++){
        string verify_val;
        if (i < 2){
            verify_val = "value_" + to_string(i + 1);
        }
        else if (i < 5){
            verify_val = "value_" + to_string(i + 2);
        }
        else{
            verify_val = "value_" + to_string(i + 3);
        }
        cout << new_ID_ptr_1->requestData(keys[i]) << verifyString(new_ID_ptr_1->requestData(keys[i]), verify_val) << endl;
    }
    cout << endl;
    cout << "Now attempting to re-remove key / value pairs 3 and 7..." << endl;
    new_ID_ptr_1->removeAttribute("key_3");
    new_ID_ptr_1->removeAttribute("key_7");
    keys = new_ID_ptr_1->requestDataMap();
    cout << "Now all of the keys and values are..." << endl;
    for (int i = 0; i < new_ID_ptr_1->getNumAttributes(); i++){
        string verify_key;
        if (i < 2){
            verify_key = "key_" + to_string(i + 1);
        }
        else if (i < 5){
            verify_key = "key_" + to_string(i + 2);
        }
        else{
            verify_key = "key_" + to_string(i + 3);
        }
        cout << keys[i] << verifyString(keys[i], verify_key) << endl;
    }
    cout << endl;
    for (int i = 0; i < new_ID_ptr_1->getNumAttributes(); i++){
        string verify_val;
        if (i < 2){
            verify_val = "value_" + to_string(i + 1);
        }
        else if (i < 5){
            verify_val = "value_" + to_string(i + 2);
        }
        else{
            verify_val = "value_" + to_string(i + 3);
        }
        cout << new_ID_ptr_1->requestData(keys[i]) << verifyString(new_ID_ptr_1->requestData(keys[i]), verify_val) << endl;
    }
    cout << endl;

    return 0;
}

/* Border-printing function for separating tests */
void printBorder(){
    for (int i = 0; i < 100; i++){
        cout << "*";
    }
    cout << endl;
}
/* Examines whether 2 strings are identical.
   If so, prints SUCCESS. If not, prints FAIL */
string verifyString(string string_1, string string_2){
    if (string_1 == string_2){
        return " ...SUCCESS ";
    }
    else{
        return " ...FAIL ";
    }
}
void verifyStringPrint(string string_1, string string_2){
    if (string_1 == string_2){
        cout <<  " ...SUCCESS ";
    }
    else{
        cout <<  " ...FAIL ";
    }
}
/* Examines whether 2 integers are identical.
   If so, prints SUCCESS. If not, prints FAIL */
string verifyInt(int int_1, int int_2){
    if (int_1 == int_2){
        return " ...SUCCESS ";
    }
    else{
        return " ...FAIL ";
    }
}
void verifyIntPrint(int int_1, int int_2){
    if (int_1 == int_2){
        cout <<  " ...SUCCESS ";
    }
    else{
        cout <<  " ...FAIL ";
    }
}
/* Examines whether statement is true.
   If so, prints SUCCESS. If not, prints FAIL */
string verifyBool(bool expression){
    if (expression){
        return " ...SUCCESS ";
    }
    else{
        return " ...FAIL ";
    }
}
void verifyBoolPrint(bool expression){
    if (expression){
        cout << " ...SUCCESS ";
    }
    else{
        cout << " ...FAIL";
    }
}
